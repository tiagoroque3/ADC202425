    package com.tiago.adc.model;

    public class AccountStateRequest {
        public String sessionToken;
        public String targetUsername;
        public String newState;
    }

