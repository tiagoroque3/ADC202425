package com.tiago.adc.model;

public class PasswordChangeRequest {
    public String token;
    public String passwordAtual;
    public String novaPassword;
    public String confirmacaoNovaPassword;
}

