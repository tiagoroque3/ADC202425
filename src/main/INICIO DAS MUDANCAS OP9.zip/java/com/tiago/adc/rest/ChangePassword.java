package com.tiago.adc.rest;

import com.google.cloud.datastore.*;
import com.tiago.adc.model.PasswordChangeRequest;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/changepassword")
public class ChangePassword {

    private static final String KIND = "User";

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response changePassword(PasswordChangeRequest req) {
        try {
            Datastore datastore = DatastoreOptions.getDefaultInstance().getService();

            if (req.username == null || req.passwordAtual == null || 
                req.novaPassword == null || req.confirmacaoNovaPassword == null) {
                return Response.status(400).entity("{\"erro\": \"Campos obrigatórios em falta\"}").build();
            }

            if (!req.novaPassword.equals(req.confirmacaoNovaPassword)) {
                return Response.status(400).entity("{\"erro\": \"Nova password e confirmação não coincidem\"}").build();
            }

            Key userKey = datastore.newKeyFactory().setKind(KIND).newKey(req.username);
            Entity user = datastore.get(userKey);
            if (user == null) {
                return Response.status(404).entity("{\"erro\": \"Utilizador não encontrado\"}").build();
            }

            String currentPassword = user.getString("password");

            if (!currentPassword.equals(req.passwordAtual)) {
                return Response.status(403).entity("{\"erro\": \"Password atual incorreta\"}").build();
            }

            Entity updated = Entity.newBuilder(user)
                    .set("password", req.novaPassword)
                    .build();

            datastore.put(updated);

            return Response.ok("{\"mensagem\": \"Password alterada com sucesso\"}").build();

        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(500).entity("{\"erro\": \"Erro interno\"}").build();
        }
    }
}
