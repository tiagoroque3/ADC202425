package com.tiago.adc.rest;

import com.google.cloud.datastore.*;
import com.tiago.adc.model.ChangeAttributesRequest;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Map;
import java.util.Set;

@Path("/changeattributes")
public class ChangeAccountAttributes {

    private static final String KIND = "User";

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response changeAttributes(ChangeAttributesRequest req) {
        try {
            if (req.requesterUsername == null || req.targetUsername == null || req.newAttributes == null) {
                return Response.status(400).entity("{\"erro\": \"Campos obrigatórios em falta\"}").build();
            }

            Datastore datastore = DatastoreOptions.getDefaultInstance().getService();
            Key requesterKey = datastore.newKeyFactory().setKind(KIND).newKey(req.requesterUsername);
            Key targetKey = datastore.newKeyFactory().setKind(KIND).newKey(req.targetUsername);

            Entity requester = datastore.get(requesterKey);
            Entity target = datastore.get(targetKey);

            if (requester == null || target == null) {
                return Response.status(404).entity("{\"erro\": \"Utilizador não encontrado\"}").build();
            }

            String requesterRole = requester.getString("role").toLowerCase();
            String targetRole = target.getString("role").toLowerCase();
            String targetEstado = target.getString("estado").toUpperCase();

            // 🔒 Regras de permissão
            if (requesterRole.equals("enduser")) {
                if (!req.requesterUsername.equals(req.targetUsername)) {
                    return Response.status(403).entity("{\"erro\": \"ENDUSER só pode editar a própria conta\"}").build();
                }
                if (!targetEstado.equals("ATIVADA")) {
                    return Response.status(403).entity("{\"erro\": \"Conta deve estar ativada\"}").build();
                }
                Set<String> proibidos = Set.of("username", "email", "nome", "role", "estado");
                for (String key : req.newAttributes.keySet()) {
                    if (proibidos.contains(key.toLowerCase())) {
                        return Response.status(403).entity("{\"erro\": \"Não pode alterar o campo: " + key + "\"}").build();
                    }
                }

            } else if (requesterRole.equals("backoffice")) {
                if (!(targetRole.equals("enduser") || targetRole.equals("partner"))) {
                    return Response.status(403).entity("{\"erro\": \"Só pode editar contas ENDUSER ou PARTNER\"}").build();
                }
                if (!targetEstado.equals("ATIVADA")) {
                    return Response.status(403).entity("{\"erro\": \"A conta não está ativada\"}").build();
                }
                Set<String> proibidos = Set.of("username", "email");
                for (String key : req.newAttributes.keySet()) {
                    if (proibidos.contains(key.toLowerCase())) {
                        return Response.status(403).entity("{\"erro\": \"Não pode alterar o campo: " + key + "\"}").build();
                    }
                }

            } else if (!requesterRole.equals("admin")) {
                return Response.status(403).entity("{\"erro\": \"Role sem permissões para editar atributos\"}").build();
            }

            // ✅ Construir novo entity com os atributos atualizados
            Entity.Builder builder = Entity.newBuilder(target);
            for (Map.Entry<String, String> entry : req.newAttributes.entrySet()) {
                builder.set(entry.getKey(), entry.getValue());
            }

            datastore.put(builder.build());
            return Response.ok("{\"mensagem\": \"Atributos atualizados com sucesso\"}").build();

        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(500).entity("{\"erro\": \"Erro interno\"}").build();
        }
    }
}
