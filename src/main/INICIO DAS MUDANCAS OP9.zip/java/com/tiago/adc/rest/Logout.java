package com.tiago.adc.rest;

import com.google.cloud.datastore.*;
import com.tiago.adc.model.LogoutRequest;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/logout")
public class Logout {

    private static final String SESSION_KIND = "Session";

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response logoutUser(LogoutRequest req) {
        try {
            if (req == null || req.token == null || req.token.trim().isEmpty()) {
                return Response.status(400).entity("{\"erro\": \"Token obrigatório\"}").build();
            }

            Datastore datastore = DatastoreOptions.getDefaultInstance().getService();

            // Procurar sessão pelo token (verificador)
            Query<Entity> query = Query.newEntityQueryBuilder()
                    .setKind(SESSION_KIND)
                    .setFilter(
                            StructuredQuery.CompositeFilter.and(
                                    StructuredQuery.PropertyFilter.eq("verificador", req.token),
                                    StructuredQuery.PropertyFilter.eq("active", true)
                            )
                    )
                    .build();

            QueryResults<Entity> sessions = datastore.run(query);

            if (!sessions.hasNext()) {
                return Response.status(404).entity("{\"erro\": \"Sessão não encontrada ou já encerrada\"}").build();
            }

            Entity session = sessions.next();
            Entity updated = Entity.newBuilder(session)
                    .set("active", false)
                    .build();

            datastore.put(updated);

            return Response.ok("{\"mensagem\": \"Logout efetuado com sucesso\"}").build();

        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(500).entity("{\"erro\": \"Erro interno\"}").build();
        }
    }
}
