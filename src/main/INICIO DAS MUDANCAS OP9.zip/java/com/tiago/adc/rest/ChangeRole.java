package com.tiago.adc.rest;

import com.google.cloud.datastore.*;
import com.tiago.adc.model.RoleRequest;
import com.tiago.adc.util.SessionUtils;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Set;

@Path("/changerole")
public class ChangeRole {

    private static final String KIND = "User";
    private static final Set<String> VALID_ROLES = Set.of("admin", "backoffice", "moderator", "enduser", "partner");

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response changeRole(RoleRequest req) {
        try {
        	 Datastore datastore = DatastoreOptions.getDefaultInstance().getService();

             if (!SessionUtils.isSessionValid(datastore, req.token)) {
                 return Response.status(401).entity("{\"erro\": \"Sessão inválida ou expirada\"}").build();
             }

             Entity session = SessionUtils.getSessionEntity(datastore, req.token);
             //String requesterUsername = session.getString("user");
             String requesterRole = session.getString("role").toLowerCase();

             //mudei esta parte acima para o OP9
             
             
             
            if (!(requesterRole.equals("admin") || requesterRole.equals("backoffice"))) {
                return Response.status(403).entity("{\"erro\": \"Permissões insuficientes\"}").build();
            }

            // Validar novo role
            String newRole = req.newRole.toLowerCase();
            if (!VALID_ROLES.contains(newRole)) {
                return Response.status(400).entity("{\"erro\": \"Role inválido\"}").build();
            }

            // Buscar o utilizador alvo
            Key targetKey = datastore.newKeyFactory().setKind(KIND).newKey(req.targetUsername);
            Entity target = datastore.get(targetKey);

            if (target == null) {
                return Response.status(404).entity("{\"erro\": \"Utilizador não encontrado\"}").build();
            }

            String currentRole = target.getString("role").toLowerCase();

            // 🔐 RESTRIÇÕES de BACKOFFICE
            if (requesterRole.equals("backoffice")) {
                boolean validChange = 
                    (currentRole.equals("enduser") && newRole.equals("partner")) ||
                    (currentRole.equals("partner") && newRole.equals("enduser"));

                if (!validChange) {
                    return Response.status(403).entity("{\"erro\": \"Backoffice só pode alterar entre enduser e partner\"}").build();
                }
            }

            // Atualiza o role
            Entity updated = Entity.newBuilder(target)
                    .set("role", newRole)
                    .build();
            datastore.put(updated);

            return Response.ok("{\"mensagem\": \"Role atualizado com sucesso\"}").build();

        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(500).entity("{\"erro\": \"Erro interno\"}").build();
        }
    }
}
