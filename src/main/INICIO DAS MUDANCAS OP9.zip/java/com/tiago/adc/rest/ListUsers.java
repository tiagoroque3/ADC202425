package com.tiago.adc.rest;

import com.google.cloud.datastore.*;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.*;

@Path("/listusers")
public class ListUsers {

    private static final String KIND = "User";
    private static final List<String> CAMPOS_OBRIGATORIOS = List.of("username", "email", "nome");

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response listUsers(Map<String, String> request) {
        try {
            Datastore datastore = DatastoreOptions.getDefaultInstance().getService();

            String requesterUsername = request.get("requesterUsername");
            if (requesterUsername == null || requesterUsername.trim().isEmpty()) {
                return Response.status(400).entity("{\"erro\": \"Campo requesterUsername em falta\"}").build();
            }

            Key requesterKey = datastore.newKeyFactory().setKind(KIND).newKey(requesterUsername);
            Entity requester = datastore.get(requesterKey);
            if (requester == null) {
                return Response.status(403).entity("{\"erro\": \"Utilizador não encontrado\"}").build();
            }

            String requesterRole = requester.getString("role").toLowerCase();

            Query<Entity> query = Query.newEntityQueryBuilder().setKind(KIND).build();
            QueryResults<Entity> results = datastore.run(query);

            List<Map<String, String>> utilizadores = new ArrayList<>();

            while (results.hasNext()) {
                Entity user = results.next();

                String role = user.getString("role").toLowerCase();
                String estado = user.contains("estado") ? user.getString("estado").toUpperCase() : "NOT DEFINED";
                String perfil = user.contains("perfil") ? user.getString("perfil").toLowerCase() : "privado";

                boolean podeVer = false;

                if (requesterRole.equals("admin")) {
                    podeVer = true;
                } else if (requesterRole.equals("backoffice")) {
                    podeVer = role.equals("enduser");
                } else if (requesterRole.equals("enduser")) {
                    podeVer = role.equals("enduser") && perfil.equals("publico") && estado.equals("ATIVADA");
                }

                if (!podeVer) continue;

                Map<String, String> userData = new LinkedHashMap<>();

                if (requesterRole.equals("enduser")) {
                	for (String campo : CAMPOS_OBRIGATORIOS) {
                	    if (campo.equals("username")) {
                	        userData.put("username", user.getKey().getName());
                	    } else {
                	        userData.put(campo, user.contains(campo) ? user.getString(campo) : "NOT DEFINED");
                	    }
                	}
                } else {
                    // Mostrar todos os atributos
                    for (String nomeCampo : user.getNames()) {
                        String valor = user.getString(nomeCampo);
                        userData.put(nomeCampo, valor != null ? valor : "NOT DEFINED");
                    }
                }

                utilizadores.add(userData);
            }

            return Response.ok(utilizadores).build();

        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(500).entity("{\"erro\": \"Erro interno\"}").build();
        }
    }
}
