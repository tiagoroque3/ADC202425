package com.tiago.adc.rest;

import com.google.cloud.datastore.*;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/deleteuser")
public class DeleteUser {

    private static final String KIND = "User";

    @DELETE
    @Path("/{username}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteUser(
            @PathParam("username") String username,
            @QueryParam("requester") String requesterUsername) {

        try {
            Datastore datastore = DatastoreOptions.getDefaultInstance().getService();

            // Validar quem está a fazer o pedido
            if (requesterUsername == null || requesterUsername.isEmpty()) {
                return Response.status(400).entity("{\"erro\": \"Requester em falta\"}").build();
            }

            // Obter info do requester
            Key requesterKey = datastore.newKeyFactory().setKind(KIND).newKey(requesterUsername);
            Entity requester = datastore.get(requesterKey);

            if (requester == null) {
                return Response.status(404).entity("{\"erro\": \"Requester não encontrado\"}").build();
            }

            String requesterRole = requester.getString("role").toLowerCase();

            // Não deixar ENDUSER apagar ninguém
            if (requesterRole.equals("enduser")) {
                return Response.status(403).entity("{\"erro\": \"ENDUSER não tem permissões para apagar utilizadores\"}").build();
            }

            // Obter o utilizador alvo
            Key userKey = datastore.newKeyFactory().setKind(KIND).newKey(username);
            Entity target = datastore.get(userKey);

            if (target == null) {
                return Response.status(404).entity("{\"erro\": \"Utilizador não encontrado\"}").build();
            }

            String targetRole = target.getString("role").toLowerCase();

            // BACKOFFICE só pode apagar enduser ou partner
            if (requesterRole.equals("backoffice") &&
                    !(targetRole.equals("enduser") || targetRole.equals("partner"))) {
                return Response.status(403).entity("{\"erro\": \"BACKOFFICE só pode apagar ENDUSER ou PARTNER\"}").build();
            }

            // Apagar utilizador
            datastore.delete(userKey);

            return Response.ok("{\"mensagem\": \"Utilizador apagado com sucesso\"}").build();

        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(500).entity("{\"erro\": \"Erro interno\"}").build();
        }
    }
}
