package com.tiago.adc.model;

public class LoginResponse {
    public String user;
    public String role;
    public String valid_from;
    public String valid_to;
    public String verificador;
}
