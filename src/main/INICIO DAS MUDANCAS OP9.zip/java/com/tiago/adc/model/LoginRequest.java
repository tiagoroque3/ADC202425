package com.tiago.adc.model;

public class LoginRequest {
    public String identificador; // username ou email
    public String password;

    public LoginRequest() {}
}
