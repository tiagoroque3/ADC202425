package com.tiago.adc.model;

import java.util.Map;

public class ChangeAttributesRequest {
    public String requesterUsername;  // quem quer fazer a alteração
    public String targetUsername;     // conta a ser alterada
    public Map<String, String> newAttributes;  // atributos a modificar
}
