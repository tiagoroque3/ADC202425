package com.tiago.adc.model;

public class PasswordChangeRequest {
    public String username;
    public String passwordAtual;
    public String novaPassword;
    public String confirmacaoNovaPassword;
}
