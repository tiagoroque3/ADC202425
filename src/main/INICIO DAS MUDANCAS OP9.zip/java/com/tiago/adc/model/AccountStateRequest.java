    package com.tiago.adc.model;

    public class AccountStateRequest {
        public String token;
        public String targetUsername;
        public String newState;
        //public String requesterUsername;


        public AccountStateRequest() {
        }

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public String getTargetUsername() {
            return targetUsername;
        }

        public void setTargetUsername(String targetUsername) {
            this.targetUsername = targetUsername;
        }

        public String getNewState() {
            return newState;
        }

        public void setNewState(String newState) {
            this.newState = newState;
        }
    }
