package com.tiago.adc.model;

public class LogoutRequest {
    public String token;

    public LogoutRequest() {}
}
